export interface JsonLdGet {

    'hydra:member' :Array<any>;

    'hydra:totalItems' :number;
}